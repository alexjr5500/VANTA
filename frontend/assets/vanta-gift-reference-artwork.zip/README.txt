VANTA virtual gift reference artwork
70 static WebP crops from the supplied reference.
No price/name change has been applied to the live application.
Original crop resolution varies by row; recreate from high-resolution original art for animations or large display.
Reference prices are transcribed only for comparison.
